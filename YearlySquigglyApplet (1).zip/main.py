# Definición de la cadena de datos
dato = "oso,perro,10,5 son animales"

# Salida esperada
print("oso es un palindromo")
print("perro no es un palindromo")
print("tenemos 5 oso")
print("tenemos 10 perros")
print("oso y perro son animales")

# Procesamiento de la cadena de datos
animales = []
animales.append(dato.split(",")[0])
animales.append(dato.split(",")[1])

# Verificación de palíndromos
for animal in animales:
    if animal == animal[::-1]:
        print(f"{animal} es un palindromo")
    else:
        print(f"{animal} no es un palindromo")

# Impresión de la información
print(f"Tenemos {dato.split(',')[3][:-1]} {animales[0]}")
print(f"Tenemos {dato.split(',')[2]} {animales[1]}")